from telegram.ext import Updater, MessageHandler, Filters

TOKEN = "8153348997:AAFY4NszVKwMS4Fbvc70rhwZA-lA5rWK6Po"

def handle_message(update, context):
    text = update.message.text.lower()
    gaali_list = ["bc", "mc", "bhosd", "chutiya", "madarchod", "gandu", "lund", "randi"]

    if any(gaali in text for gaali in gaali_list):
        update.message.reply_text("Gaali mat de be ullu ke patthe 🤬")
    else:
        update.message.reply_text("Mujhe sab sunayi deta hai 😎")

updater = Updater(TOKEN, use_context=True)
dp = updater.dispatcher
dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))
updater.start_polling()
updater.idle()
